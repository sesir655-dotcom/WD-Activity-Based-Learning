const nav = document.getElementById('nav');
document.getElementById('menuBtn').addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
const filters = document.querySelectorAll('.filter');
const courses = document.querySelectorAll('.course');
filters.forEach(button => button.addEventListener('click', () => {
  filters.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const selected = button.dataset.filter;
  courses.forEach(course => course.hidden = selected !== 'all' && course.dataset.category !== selected);
}));
document.querySelectorAll('.enroll').forEach(button => button.addEventListener('click', () => {
  document.getElementById('notice').textContent = `You selected "${button.dataset.course}". This is a demo interface; enrollment is not connected to a server.`;
}));
