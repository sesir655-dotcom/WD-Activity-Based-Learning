const nav = document.getElementById('nav');
document.getElementById('menuBtn').addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => nav.classList.remove('open')));
const filters = document.querySelectorAll('.filter');
const products = document.querySelectorAll('.product');
filters.forEach(button => button.addEventListener('click', () => {
  filters.forEach(item => item.classList.remove('active'));
  button.classList.add('active');
  const selected = button.dataset.filter;
  products.forEach(product => product.hidden = selected !== 'all' && product.dataset.category !== selected);
}));
let count = 0, total = 0;
document.querySelectorAll('.add').forEach(button => button.addEventListener('click', () => {
  count += 1; total += Number(button.dataset.price);
  document.getElementById('cartCount').textContent = count;
  document.getElementById('cartTotal').textContent = `₹${total}`;
  document.getElementById('orderMessage').textContent = `${button.dataset.name} added to your demo basket.`;
}));
document.getElementById('checkout').addEventListener('click', () => {
  document.getElementById('orderMessage').textContent = count ? `Your demo basket contains ${count} item(s), estimated total ₹${total}. No real order has been placed.` : 'Your basket is empty. Add a treat first!';
});
document.getElementById('orderForm').addEventListener('submit', event => {
  event.preventDefault();
  document.getElementById('formMessage').textContent = `Thank you, ${document.getElementById('customer').value.trim()}! This demo enquiry was not sent to a server.`;
  event.target.reset();
});
